SHADOW SYSTEM - ANDROID PROJECT

This project wraps the supplied Shadow System camera-enabled HTML in an Android WebView.
It requests Android CAMERA permission only when the push-up camera feature is started.

BUILD APK (requires a Windows/macOS/Linux computer with Android Studio and internet):
1. Install Android Studio and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose Open and select the ShadowSystemAndroid folder.
4. Allow Gradle sync and install any requested SDK components.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

NOTES:
- The push-up pose model is loaded from jsDelivr at runtime, so internet is needed for that feature.
- Camera permission is requested at runtime. Choose Allow when prompted.
- Profile data uses WebView local storage on this device. Clearing app data may erase it; use Export Backup.
- This is an Android Studio source project, not a precompiled APK. This environment has no Android SDK/Gradle installation, so it cannot compile the APK here.
